# My BuildFree website (starter kit)

A tiny shop website that reads products from BuildFree, sends a contact form
and takes payments with Razorpay through BuildFree.

## Start

1. Install Node.js (LTS) from https://nodejs.org
2. Open this folder in a terminal and run:

   ```
   npm install
   ```

3. Rename `.env.example` to `.env` and paste your BuildFree address and API key.
4. Run:

   ```
   npm run dev
   ```

5. Open http://localhost:5173

## What BuildFree needs

- A published collection called `products` with fields `name` (Text), `price` (Number),
  `photo` (Image) and `in_stock` (Boolean)
- A published form called `contact-form` with fields `name`, `email`, `occasion`, `message`
- For payments: a published form called `order-form` with fields `name`, `email`, `phone`,
  `address`, `product`, `quantity`, `total`, and Razorpay connected in the Payments tab

## Files

```
api/buildfree.js     the safe helper – holds your API key, talks to BuildFree
src/Products.jsx     shows your products
src/ContactForm.jsx  sends the contact form
src/BuyButton.jsx    takes a payment
src/App.jsx          puts the page together
```

## Put it online

Run `npx vercel`, then add BUILDFREE_URL and BUILDFREE_KEY under
Project → Settings → Environment Variables in Vercel, and run `npx vercel --prod`.
